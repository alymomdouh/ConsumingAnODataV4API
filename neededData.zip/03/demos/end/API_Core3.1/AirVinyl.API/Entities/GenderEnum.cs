﻿namespace AirVinyl.Entities
{
    public enum Gender
    {
        Female,
        Male,
        Other
    } 
}
